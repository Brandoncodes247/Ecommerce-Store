export class CreateInventoryDto {
  productId!: string;
  quantity!: number;
}
