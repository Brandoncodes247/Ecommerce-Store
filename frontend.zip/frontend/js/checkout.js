// js/checkout.js
import { getCart, setCart, updateCartCount } from './utils/storage.js';
import { showToast } from './utils/ui.js';
import { checkAuth } from './auth.js';

// Address Autocomplete Utility
class AddressAutocomplete {
  constructor(inputElement, suggestionsContainer) {
    this.input = inputElement;
    this.suggestions = suggestionsContainer;
    this.debounceTimer = null;
    
    this.init();
  }

  init() {
    this.input.addEventListener('input', () => this.handleInput());
    document.addEventListener('click', (e) => {
      if (!this.input.contains(e.target) && !this.suggestions.contains(e.target)) {
        this.clearSuggestions();
      }
    });
  }

  handleInput() {
    clearTimeout(this.debounceTimer);
    const query = this.input.value.trim();
    
    if (query.length < 3) {
      this.clearSuggestions();
      return;
    }

    this.debounceTimer = setTimeout(() => this.fetchSuggestions(query), 400);
  }

  async fetchSuggestions(query) {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&addressdetails=1&limit=5`
      );
      const data = await response.json();
      this.displaySuggestions(data);
    } catch (error) {
      console.error('Address suggestion error:', error);
    }
  }

  displaySuggestions(data) {
    this.clearSuggestions();
    
    data.forEach(item => {
      const div = document.createElement('div');
      div.textContent = item.display_name;
      div.onclick = () => {
        this.input.value = item.display_name;
        this.clearSuggestions();
      };
      this.suggestions.appendChild(div);
    });
  }

  clearSuggestions() {
    this.suggestions.innerHTML = '';
  }
}

document.addEventListener('DOMContentLoaded', function () {
  // Initialize auth check
  if (!checkAuth()) {
    showToast('Please log in to continue checkout.', 'error');
    setTimeout(() => (window.location.href = 'index.html'), 2000);
    return;
  }

  // Initialize address autocomplete
  const addressInput = document.getElementById('address');
  const suggestionsBox = document.getElementById('address-suggestions');
  if (addressInput && suggestionsBox) {
    new AddressAutocomplete(addressInput, suggestionsBox);
  }

  // Cart and checkout logic
  const cart = getCart();
  if (!cart || cart.length === 0) {
    showToast('Your cart is empty. Redirecting...', 'info');
    setTimeout(() => (window.location.href = 'index.html'), 2000);
    return;
  }

  // Calculate order totals
  let subtotal = 0;
  cart.forEach(item => {
    const price = parseFloat(item.price);
    const qty = parseInt(item.qty);
    if (!isNaN(price) && !isNaN(qty)) subtotal += price * qty;
  });

  const shipping = 500;
  const tax = Math.round(subtotal * 0.16);
  const total = subtotal + shipping + tax;

  // Update UI with calculated amounts
  document.getElementById('subtotal-amount').textContent = `KES ${subtotal.toLocaleString()}`;
  document.getElementById('shipping-amount').textContent = `KES ${shipping.toLocaleString()}`;
  document.getElementById('tax-amount').textContent = `KES ${tax.toLocaleString()}`;
  document.getElementById('total-amount').textContent = `KES ${total.toLocaleString()}`;

  // Render cart items
  const cartItemsContainer = document.getElementById('cart-items');
  if (cartItemsContainer) {
    cartItemsContainer.innerHTML = cart.map(item => {
      const imageUrl = item.imageUrl || item.image || '';
      return `
        <div class="cart-item">
          <img src="${imageUrl}" alt="${item.name}">
          <div class="cart-item-details">
            <h3>${item.name}</h3>
            <p>KES ${Number(item.price).toLocaleString()} × ${item.qty}</p>
          </div>
        </div>
      `;
    }).join('');
  }

  // Payment method toggle
  document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
    radio.addEventListener('change', function () {
      document.querySelectorAll('.payment-details').forEach(div => div.classList.remove('active'));
      document.getElementById(this.value + '-details').classList.add('active');
    });
  });

  // Payment submission
  document.getElementById('pay-button').addEventListener('click', async function (e) {
    e.preventDefault();

    const shippingForm = document.getElementById('shipping-form');
    const inputs = shippingForm.querySelectorAll('input[required]');
    let allFieldsFilled = true;

    inputs.forEach(input => {
      const parent = input.closest('.payment-details');
      const hidden = parent && !parent.classList.contains('active');
      if (hidden) return;
      
      if (!input.value.trim()) {
        input.classList.add('error');
        allFieldsFilled = false;
      } else {
        input.classList.remove('error');
      }
    });

    if (!allFieldsFilled) {
      showToast('Please fill in all required details.', 'error');
      return;
    }

    showToast('Processing your order...', 'info');

    // Validate and prepare order items
    const validItems = cart.map(item => ({
      productId: parseInt(item.id),
      quantity: parseInt(item.qty),
      price: parseFloat(item.price)
    })).filter(item =>
      !isNaN(item.productId) &&
      !isNaN(item.quantity) &&
      !isNaN(item.price)
    );

    const orderPayload = {
      items: validItems,
      totalAmount: validItems.reduce((acc, item) => acc + item.price * item.quantity, 0) + shipping + tax,
      paymentMethod: document.querySelector('input[name="paymentMethod"]:checked').value
    };

    try {
      const response = await fetch('http://localhost:3001/api/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });

      if (response.ok) {
        const result = await response.json();
        showToast('✅ Order placed successfully!', 'success');
        localStorage.setItem('lastOrderId', result.id);
        setCart([]);
        updateCartCount();
        setTimeout(() => {
          window.location.href = 'thankyou.html';
        }, 2000);
      } else {
        const errorData = await response.json();
        showToast(`❌ Order failed: ${errorData.message || 'Please try again'}`, 'error');
      }
    } catch (err) {
      console.error('Order error:', err);
      showToast('❌ Network error during order processing', 'error');
    }
  });
});
