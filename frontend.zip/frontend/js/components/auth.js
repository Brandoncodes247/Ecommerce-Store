// js/auth.js
import { auth } from './firebase-config.js';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import { showToast } from '/js/utils/ui.js';

class Auth {
  constructor() {
    this.loginBtn = document.getElementById('login-btn');
    this.authModal = document.getElementById('auth-modal');
    this.loginForm = document.getElementById('login-form');
    this.signupForm = document.getElementById('signup-form');

    // Initialize auth state listener
    onAuthStateChanged(auth, (user) => this.updateAuthButton(user));

    if (this.loginForm) {
      this.loginForm.addEventListener('submit', (e) => this.handleLogin(e));
    }

    if (this.signupForm) {
      this.signupForm.addEventListener('submit', (e) => this.handleSignup(e));
    }
  }

  updateAuthButton(user) {
    if (this.loginBtn) {
      if (user) {
        this.loginBtn.textContent = `Welcome, ${user.email.split('@')[0]}`;
        this.loginBtn.onclick = () => this.logout();
      } else {
        this.loginBtn.textContent = 'Login / Sign Up';
        this.loginBtn.onclick = () => {
          if (this.authModal) {
            this.authModal.style.display = 'flex';
            document.getElementById('login-form').style.display = 'block';
            document.getElementById('signup-form').style.display = 'none';
          }
        };
      }
    }
  }

  handleLogin(event) {
    event.preventDefault();
    const email = this.loginForm.querySelector('input[type="email"]').value;
    const password = this.loginForm.querySelector('input[type="password"]').value;

    signInWithEmailAndPassword(auth, email, password)
      .then(() => {
        if (this.authModal) this.authModal.style.display = 'none';
        showToast("Logged in successfully!");
      })
      .catch(err => showToast(err.message, 'error'));
  }

  handleSignup(event) {
    event.preventDefault();
    const name = this.signupForm.querySelector('input[type="text"]').value;
    const email = this.signupForm.querySelector('input[type="email"]').value;
    const password = this.signupForm.querySelectorAll('input[type="password"]')[0].value;
    const confirmPassword = this.signupForm.querySelectorAll('input[type="password"]')[1].value;

    if (password !== confirmPassword) {
      showToast("Passwords do not match!", 'error');
      return;
    }

    createUserWithEmailAndPassword(auth, email, password)
      .then(() => {
        if (this.authModal) this.authModal.style.display = 'none';
        showToast("Account created successfully!");
      })
      .catch(err => showToast(err.message, 'error'));
  }

  logout() {
    signOut(auth)
      .then(() => showToast("Logged out successfully!"))
      .catch(err => showToast(err.message, 'error'));
  }

  checkAuthForCheckout() {
    const user = auth.currentUser;
    if (!user) {
      showToast("Please login to proceed to checkout", 'error');
      if (this.authModal) this.authModal.style.display = 'flex';
      return false;
    }
    return true;
  }
}

// Create singleton instance
const authInstance = new Auth();

// Export functions for direct usage
export function checkAuth() {
  return authInstance.checkAuthForCheckout();
}

export default authInstance;
